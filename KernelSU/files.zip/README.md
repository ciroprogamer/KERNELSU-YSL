# Android Kernel 4.9 - Memory Allocation Limit Patch

## Problem
Your Android kernel is experiencing crashes and soft reboots because some function is trying to allocate memory that's 4x your RAM size. This patch adds intelligent allocation limits that ignore unreasonable requests and calculate safe sizes automatically.

## Solution Overview
This patch adds a **dual-limit system**:

1. **Absolute Maximum**: Hard cap (default 8MB for normal, 64MB for DMA)
2. **Dynamic Limit**: Based on available RAM (default 5% of available memory)

The system will use whichever is SMALLER, ensuring safety while adapting to memory pressure.

---

## Patch Versions

### 1. **alloc_limit_simple.patch** (RECOMMENDED)
- Simplest to apply and use
- Module parameters for easy runtime configuration
- Just adds the core protection
- **Best for first-time use**

### 2. **alloc_limit.patch** (Advanced)
- Full featured with statistics tracking
- Sysctl interface
- More detailed logging
- Use if you need detailed monitoring

---

## Installation

### Step 1: Apply the patch

```bash
cd /path/to/your/kernel/source
patch -p1 < alloc_limit_simple.patch
```

If you get errors, you can apply manually (instructions below).

### Step 2: Rebuild the kernel

```bash
make -j$(nproc)
```

### Step 3: Flash the new kernel to your Android device

```bash
# This depends on your device, but typically:
fastboot flash boot boot.img
# or
adb reboot bootloader
fastboot flash kernel Image.gz-dtb
```

---

## Configuration (Runtime)

The simple patch uses **module parameters** that can be changed at runtime:

### View current settings:
```bash
adb shell
cat /sys/module/page_alloc/parameters/max_alloc_mb
cat /sys/module/page_alloc/parameters/dma_max_alloc_mb
cat /sys/module/page_alloc/parameters/max_alloc_percent
cat /sys/module/page_alloc/parameters/enforce_limits
```

### Change settings:
```bash
# Set maximum allocation to 4MB (more conservative)
echo 4 > /sys/module/page_alloc/parameters/max_alloc_mb

# Set DMA max to 32MB
echo 32 > /sys/module/page_alloc/parameters/dma_max_alloc_mb

# Allow up to 10% of available RAM per allocation
echo 10 > /sys/module/page_alloc/parameters/max_alloc_percent

# Disable enforcement temporarily (for testing)
echo 0 > /sys/module/page_alloc/parameters/enforce_limits
```

### Make settings permanent:
Add to your kernel boot parameters in bootimg.cfg or similar:
```
page_alloc.max_alloc_mb=4 page_alloc.max_alloc_percent=5
```

---

## Recommended Settings

### Conservative (Prevents most crashes):
```bash
max_alloc_mb=4           # 4MB max for normal allocations
dma_max_alloc_mb=32      # 32MB max for DMA
max_alloc_percent=3      # 3% of available RAM
```

### Balanced (Default):
```bash
max_alloc_mb=8           # 8MB max for normal allocations
dma_max_alloc_mb=64      # 64MB max for DMA
max_alloc_percent=5      # 5% of available RAM
```

### Permissive (For debugging):
```bash
max_alloc_mb=16          # 16MB max
dma_max_alloc_mb=128     # 128MB for DMA
max_alloc_percent=10     # 10% of available RAM
```

---

## How It Works

### Before (Crash scenario):
```
App/Driver: "I need 16GB of RAM!"
Kernel: "OK, trying to allocate 16GB..."
System: *CRASH* 💥
```

### After (With patch):
```
App/Driver: "I need 16GB of RAM!"
Kernel: "Available: 2GB, you can have max 100MB (5%)"
Kernel: "Clamping 16GB → 100MB"
System: ✅ Continues working
```

---

## Monitoring

### Check kernel logs for clamping events:
```bash
adb shell dmesg | grep -i "ALLOC_CLAMP\|ALLOC_BLOCK"
```

You'll see messages like:
```
ALLOC_CLAMP: camera_hal[1234] requested 2048 MB, limiting to 64 MB (available: 1280 MB)
ALLOC_BLOCK: buggy_driver[5678] tried to allocate 8192 MB (max: 64 MB)! BLOCKED.
```

### Identify the culprit:
The logs show the **process name** and **PID** of what's requesting huge allocations.

---

## Manual Application (If patch fails)

If the patch command fails, manually edit `/mm/page_alloc.c`:

### 1. Find line 126-128 (where totalram_pages is defined):
```c
unsigned long totalram_pages __read_mostly;
unsigned long totalreserve_pages __read_mostly;
unsigned long totalcma_pages __read_mostly;
```

### 2. Add AFTER those lines:
```c
static unsigned int max_alloc_mb = 8;
module_param(max_alloc_mb, uint, 0644);
MODULE_PARM_DESC(max_alloc_mb, "Maximum allocation size in MB");

static unsigned int dma_max_alloc_mb = 64;
module_param(dma_max_alloc_mb, uint, 0644);
MODULE_PARM_DESC(dma_max_alloc_mb, "Maximum DMA allocation size in MB");

static unsigned int max_alloc_percent = 5;
module_param(max_alloc_percent, uint, 0644);
MODULE_PARM_DESC(max_alloc_percent, "Max allocation as % of available RAM");

static bool enforce_limits = true;
module_param(enforce_limits, bool, 0644);
MODULE_PARM_DESC(enforce_limits, "Enforce allocation limits");
```

### 3. Find the function `__alloc_pages_nodemask` (around line 3924):
```c
struct page *
__alloc_pages_nodemask(gfp_t gfp_mask, unsigned int order,
                      struct zonelist *zonelist, nodemask_t *nodemask)
{
    struct page *page;
    unsigned int alloc_flags = ALLOC_WMARK_LOW;
```

### 4. Add AFTER `struct page *page;` declaration:
```c
    unsigned int original_order = order;
    unsigned long requested_mb = (PAGE_SIZE << order) >> 20;
    unsigned long max_mb = (gfp_mask & (__GFP_DMA | __GFP_DMA32)) ? 
                          dma_max_alloc_mb : max_alloc_mb;
    
    /* Block excessive allocations */
    if (enforce_limits && requested_mb > (max_mb * 2)) {
        pr_err("ALLOC_BLOCK: %s[%d] tried to allocate %lu MB! BLOCKED.\n",
               current->comm, current->pid, requested_mb);
        return NULL;
    }
    
    /* Clamp to safe size */
    if (enforce_limits && requested_mb > max_mb) {
        unsigned long available = global_zone_page_state(NR_FREE_PAGES);
        unsigned long safe_mb = min(max_mb, (available >> (20 - PAGE_SHIFT)) * max_alloc_percent / 100);
        
        order = get_order(safe_mb << 20);
        pr_warn("ALLOC_CLAMP: %s[%d] requested %lu MB, limiting to %lu MB\n",
                current->comm, current->pid, requested_mb, safe_mb);
    }
```

---

## Troubleshooting

### "Camera/video not working after patch"
Camera needs larger DMA buffers. Increase:
```bash
echo 128 > /sys/module/page_alloc/parameters/dma_max_alloc_mb
```

### "Still getting crashes"
The crashing function may be requesting memory through a different path (kmalloc, vmalloc, etc). You may need to patch those too. Check dmesg to see what's allocating.

### "System feels slower"
The limits might be too conservative. Try:
```bash
echo 16 > /sys/module/page_alloc/parameters/max_alloc_mb
echo 10 > /sys/module/page_alloc/parameters/max_alloc_percent
```

### "Want to temporarily disable"
```bash
echo 0 > /sys/module/page_alloc/parameters/enforce_limits
# Test your app/driver
echo 1 > /sys/module/page_alloc/parameters/enforce_limits
```

---

## Important Notes

1. **This protects against the symptom, not the root cause.** The real fix is finding why something is requesting 4x your RAM and fixing that code.

2. **DMA allocations** (camera, video, graphics) legitimately need more memory, which is why we have separate limits for them.

3. **The kernel will now ignore unreasonable requests** and substitute its own calculated safe size.

4. **Blocked allocations return NULL**, so the requesting code needs to handle allocation failures gracefully.

---

## Finding the Real Culprit

Once the patch is applied and you see ALLOC_CLAMP messages:

```bash
# Monitor in real-time
adb shell dmesg -w | grep ALLOC_

# Save logs
adb shell dmesg > kernel.log
grep -B5 -A5 ALLOC_ kernel.log
```

Look for the process name. Common culprits in Android:
- `camera_hal` - Camera driver
- `surfaceflinger` - Display compositor  
- `gpu_driver` - Graphics driver
- Custom vendor HALs

Once identified, you can:
1. Fix the specific driver code
2. Report to device manufacturer
3. Keep the patch as a safety net

---

## Support

If you need help:
1. Share your `dmesg` output (especially ALLOC_ messages)
2. Indicate which process/driver is causing issues
3. Mention your device RAM size
4. Note when the crash occurs (camera? video? specific app?)

Good luck! 🚀
